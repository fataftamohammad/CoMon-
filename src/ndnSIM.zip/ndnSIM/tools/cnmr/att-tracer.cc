#include "att-tracer.h"
#include <fstream>
#include <string>
namespace ns3
{
	namespace ndn
	{
		// std::string AttackTracer::filename;
		// void AttackTracer::Write(std::string s)
		// {
		// 	std::ofstream out(filename.c_str(),std::fstream::app);
		// 	out<<s<<"\n";
		// 	out.close();
		// }
		// void AttackTracer::setFileName(const std::string &name)
		// {
		// 	filename=name;
		// }
	}
}