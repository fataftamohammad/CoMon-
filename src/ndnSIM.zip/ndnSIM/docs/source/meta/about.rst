=====================
About these documents
=====================

These documents are generated from `reStructuredText`_ sources by `Sphinx`_, a
document processor specifically written for the Python documentation.

.. _reStructuredText: http://docutils.sf.net/rst.html
.. _Sphinx: http://sphinx.pocoo.org/

.. In the online version of these documents, you can submit comments and suggest
   changes directly on the documentation pages.

We are always welcome for your comments about the documentation, catched typos, and
other contributions.

See :ref:`reporting-bugs` for information how to report bugs in this documentation, or ndnSIM itself.
