=========
Copyright
=========

ndnSIM and this documentation is:

Copyright © 2011-2013 University of California, Los Angeles

Copyright © 2011-2013 Alexander Afanasyev

-------

See :ref:`license` for complete license and permissions information.
