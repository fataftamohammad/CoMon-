#ifndef FILENAME_H
#define FILENAME_H
#include <string>
extern std::string filePrefix;
extern int something;
#endif
