.. _reporting-bugs:

==============
Reporting bugs
==============

To file a bug report, please use `GitHub Issues <https://github.com/NDN-Routing/ndnSIM/issues>`_ or `NDN Redmine <http://redmine.named-data.net/projects/ndnsim>`_.

To create new feature, please fork the code and submit Pull Request on GitHub.
